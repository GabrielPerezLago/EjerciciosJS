function disparar(){
    const tablero = [
        [0, 0, 1, 0, 0, 0, 1, 1],
        [0, 0, 1, 0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0, 1, 0, 0],
        [0, 0, 0, 0, 0, 1, 0, 0],
        [0, 0, 1, 1, 1, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 1, 1, 0, 0, 0],
        [0, 0, 0, 0, 0, 1, 1, 1],
    ];

    let x = document.getElementById("cordenadaX");
    let y = document.getElementById("cordenadaY");

    

    
    
}